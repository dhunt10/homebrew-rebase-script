# rebase-script
## script needs to be in bash to work.
